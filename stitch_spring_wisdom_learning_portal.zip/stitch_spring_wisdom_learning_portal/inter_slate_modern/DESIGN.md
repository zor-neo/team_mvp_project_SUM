---
name: Inter-Slate Modern
colors:
  surface: '#f9f9fe'
  surface-dim: '#d7dae4'
  surface-bright: '#f9f9fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3fb'
  surface-container: '#ecedf6'
  surface-container-high: '#e6e8f1'
  surface-container-highest: '#dfe2ed'
  on-surface: '#2f323b'
  on-surface-variant: '#5b5f68'
  inverse-surface: '#0c0e12'
  inverse-on-surface: '#9c9ca2'
  outline: '#777b84'
  outline-variant: '#aeb2bc'
  surface-tint: '#465f8a'
  primary: '#465f8a'
  on-primary: '#f8f8ff'
  primary-container: '#b1cafb'
  on-primary-container: '#28426b'
  inverse-primary: '#b1cafb'
  secondary: '#565f71'
  on-secondary: '#f8f8ff'
  secondary-container: '#dae2f8'
  on-secondary-container: '#495264'
  tertiary: '#665881'
  on-tertiary: '#fef7ff'
  tertiary-container: '#deccfd'
  on-tertiary-container: '#50426a'
  error: '#a83836'
  on-error: '#fff7f6'
  error-container: '#fa746f'
  on-error-container: '#6e0a12'
  primary-fixed: '#b1cafb'
  primary-fixed-dim: '#a3bcec'
  on-primary-fixed: '#112e56'
  on-primary-fixed-variant: '#324b75'
  secondary-fixed: '#dae2f8'
  secondary-fixed-dim: '#ccd4ea'
  on-secondary-fixed: '#374051'
  on-secondary-fixed-variant: '#535c6e'
  tertiary-fixed: '#deccfd'
  tertiary-fixed-dim: '#d0bfee'
  on-tertiary-fixed: '#3c2f56'
  on-tertiary-fixed-variant: '#594c74'
  primary-dim: '#3a537d'
  secondary-dim: '#4a5365'
  tertiary-dim: '#5a4c75'
  error-dim: '#67040d'
  background: '#f9f9fe'
  on-background: '#2f323b'
  surface-variant: '#dfe2ed'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.5px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
---

# Inter-Slate Design System

## Brand & Style
The brand identity focuses on clarity, reliability, and a professional tone. The "Inter-Slate Modern" style emphasizes stability and ease of use through rounded corners and a globally recognized sans-serif typeface. The emotional response is one of confidence, calm, and functional efficiency, moving away from high-energy contrasts toward a balanced, corporate-modern aesthetic.

## Colors
The color palette is built upon a foundation of muted, professional tones derived from a primary blue seed.
- **Primary (#5f78a4):** A professional slate blue used for key actions and brand presence.
- **Secondary (#6e778a):** A cool gray-blue that provides balance and supports secondary UI elements.
- **Tertiary (#7f709b):** A soft, muted purple used for accents that require subtle distinction.
- **Neutral (#76777c):** A balanced gray used for surfaces and text to ensure high legibility.

The system uses the `tonal_spot` variant in light mode, ensuring harmonious tonal ranges and high visual comfort.

## Typography
The system utilizes **Inter** for all typographic roles. Known for its exceptional legibility on digital screens, Inter provides a modern canvas that facilitates quick information processing.
- **Headlines:** Heavier weights (600-700) establish a clear hierarchy.
- **Body text:** Standard weight (400) provides optimal readability.
- **Labels:** Medium weights (500) and slight letter spacing are used for clarity in compact UI elements.

## Layout & Spacing
The layout operates on a standard 8px grid system. We employ a **Fluid Grid** approach for mobile views, transitioning to a more structured, centered layout on desktop.
- **Base Unit:** 8px
- **Gutter:** 16px
- **Margin:** 24px

## Elevation & Depth
Depth is established through **Tonal Layers**. Surfaces are stacked using subtle variations in background luminosity. Higher-level elements like modals use soft, low-opacity ambient shadows to indicate hierarchy without cluttering the clean aesthetic.

## Shapes
The shape language follows a **Rounded** aesthetic. Standard components feature a 0.5rem (8px) corner radius, making the interface feel accessible and modern.
- **Standard (8px):** Buttons, chips, and input fields.
- **Large (16px):** Cards and containers.
- **Extra Large (24px):** Major layout sections.

## Components
- **Buttons:** Filled buttons use the Primary Slate Blue with 8px corners.
- **Input Fields:** Feature a neutral border and 8px radius with a primary highlight on focus.
- **Cards:** Defined by tonal surface colors and 16px corners to provide clear containment.
- **Chips:** Utilize muted backgrounds with medium-weight Inter labels.
- **Lists:** Clean divisions with consistent vertical padding to maintain professional information density.